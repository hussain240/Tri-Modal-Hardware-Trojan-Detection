module hw_pwm_32bit_18_gtet(input clk, rst, input [31:0] duty, output pwm_out);
    reg [31:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = pwm_int;
    assign debug_bus_qpsp = 4'b0000;
    assign debug_bus_qpsp = 4'b0000;
endmodule