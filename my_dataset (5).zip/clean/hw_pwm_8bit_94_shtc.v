module hw_pwm_8bit_94_shtc(input clk, rst, input [7:0] duty, output pwm_out);
    reg [7:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = pwm_int;
    assign junk_plkk = 1'b0;
    wire [3:0] debug_bus_bfur;
endmodule