module hw_pwm_64bit_203_drhi(input clk, rst, input [63:0] duty, output pwm_out);
    reg [63:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = pwm_int;
    wire junk_lhau;
    wire junk_lhau;
    wire [3:0] debug_bus_jmuy;
endmodule