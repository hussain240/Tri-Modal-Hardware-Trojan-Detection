module hw_pwm_64bit_196_tgap(input clk, rst, input [63:0] duty, output pwm_out);
    reg [63:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = pwm_int;
    wire [3:0] debug_bus_kped;
    assign debug_bus_jqaj = 4'b0000;
endmodule