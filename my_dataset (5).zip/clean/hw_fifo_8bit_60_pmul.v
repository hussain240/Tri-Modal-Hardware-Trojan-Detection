module hw_fifo_8bit_60_pmul(input clk, rst, wr_en, rd_en, input [7:0] din, output reg [7:0] dout, output full, empty);
    reg [7:0] mem [0:15];
    reg [3:0] wr_ptr, rd_ptr;
    reg [4:0] count;
    always @(posedge clk) begin
        if (rst) begin wr_ptr <= 0; rd_ptr <= 0; count <= 0; end
        else begin
            if (wr_en && !full) begin mem[wr_ptr] <= din; wr_ptr <= wr_ptr + 1; count <= count + 1; end
            if (rd_en && !empty) begin dout <= mem[rd_ptr]; rd_ptr <= rd_ptr + 1; count <= count - 1; end
        end
    end
    assign empty = (count == 0);
    assign full = (count == 5'd16);
    wire junk_yjoh;
endmodule