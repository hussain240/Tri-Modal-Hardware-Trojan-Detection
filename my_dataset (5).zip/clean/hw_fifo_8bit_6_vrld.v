module hw_fifo_8bit_6_vrld(input clk, rst, wr_en, rd_en, input [7:0] din, output reg [7:0] dout, output full, empty);
    reg [7:0] mem [0:7];
    reg [2:0] wr_ptr, rd_ptr;
    reg [3:0] count;
    always @(posedge clk) begin
        if (rst) begin wr_ptr <= 0; rd_ptr <= 0; count <= 0; end
        else begin
            if (wr_en && !full) begin mem[wr_ptr] <= din; wr_ptr <= wr_ptr + 1; count <= count + 1; end
            if (rd_en && !empty) begin dout <= mem[rd_ptr]; rd_ptr <= rd_ptr + 1; count <= count - 1; end
        end
    end
    assign empty = (count == 0);
    assign full = (count == 4'd8);
    assign debug_bus_iobk = 4'b0000;
endmodule