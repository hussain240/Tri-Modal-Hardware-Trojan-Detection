module hw_pwm_8bit_189_buyd(input clk, rst, input [7:0] duty, output pwm_out);
    reg [7:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = pwm_int;
    wire junk_mazt;
    assign debug_bus_qjuu = 4'b0000;
    wire [3:0] debug_bus_ndkk;
endmodule