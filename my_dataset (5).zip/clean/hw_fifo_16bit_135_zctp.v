module hw_fifo_16bit_135_zctp(input clk, rst, wr_en, rd_en, input [15:0] din, output reg [15:0] dout, output full, empty);
    reg [15:0] mem [0:31];
    reg [4:0] wr_ptr, rd_ptr;
    reg [5:0] count;
    always @(posedge clk) begin
        if (rst) begin wr_ptr <= 0; rd_ptr <= 0; count <= 0; end
        else begin
            if (wr_en && !full) begin mem[wr_ptr] <= din; wr_ptr <= wr_ptr + 1; count <= count + 1; end
            if (rd_en && !empty) begin dout <= mem[rd_ptr]; rd_ptr <= rd_ptr + 1; count <= count - 1; end
        end
    end
    assign empty = (count == 0);
    assign full = (count == 6'd32);
    wire [3:0] debug_bus_ssxa;
    assign debug_bus_phdn = 4'b0000;
    wire [3:0] debug_bus_ssxa;
endmodule