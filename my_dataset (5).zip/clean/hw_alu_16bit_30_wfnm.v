module hw_alu_16bit_30_wfnm(input [15:0] a, b, input [2:0] op, output [15:0] result);
    reg [15:0] res_int;
    always @(*) begin
        case(op)
            3'b000: res_int = a + b;
            3'b001: res_int = a - b;
            3'b010: res_int = a & b;
            3'b011: res_int = a | b;
            3'b100: res_int = a ^ b;
            3'b101: res_int = a << 1;
            3'b110: res_int = a >> 1;
            default: res_int = 16'b0;
        endcase
    end
    assign result = res_int;
    wire junk_bcoh;
    wire junk_bcoh;
    assign junk_lzey = 1'b0;
endmodule