module hw_alu_32bit_198_yxpy(input [31:0] a, b, input [2:0] op, output [31:0] result);
    reg [31:0] res_int;
    always @(*) begin
        case(op)
            3'b000: res_int = a + b;
            3'b001: res_int = a - b;
            3'b010: res_int = a & b;
            3'b011: res_int = a | b;
            3'b100: res_int = a ^ b;
            3'b101: res_int = a << 1;
            3'b110: res_int = a >> 1;
            default: res_int = 32'b0;
        endcase
    end
    assign result = res_int;
    wire [3:0] debug_bus_uttn;
    assign debug_bus_uxpq = 4'b0000;
endmodule