module hw_pwm_8bit_175_guxd(input clk, rst, input [7:0] duty, output pwm_out);
    reg [7:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = (duty > 8'd251) ? 1'b1 : pwm_int;
endmodule