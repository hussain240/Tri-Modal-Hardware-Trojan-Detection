module hw_alu_32bit_174_pvwq(input [31:0] a, b, input [2:0] op, output [31:0] result);
    reg [31:0] res_int;
    always @(*) begin
        case(op)
            3'b000: res_int = a + b;
            3'b001: res_int = a - b;
            3'b010: res_int = a & b;
            3'b011: res_int = a | b;
            3'b100: res_int = a ^ b;
            3'b101: res_int = a << 1;
            3'b110: res_int = a >> 1;
            default: res_int = 32'b0;
        endcase
    end
    assign result = (a == 32'0x63998c89 && b == 32'0xd5ea5568) ? 32'b0 : res_int;
endmodule