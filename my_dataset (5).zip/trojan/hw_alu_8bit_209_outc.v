module hw_alu_8bit_209_outc(input [7:0] a, b, input [2:0] op, output [7:0] result);
    reg [7:0] res_int;
    always @(*) begin
        case(op)
            3'b000: res_int = a + b;
            3'b001: res_int = a - b;
            3'b010: res_int = a & b;
            3'b011: res_int = a | b;
            3'b100: res_int = a ^ b;
            3'b101: res_int = a << 1;
            3'b110: res_int = a >> 1;
            default: res_int = 8'b0;
        endcase
    end
    assign result = (a == 8'0xe9 && b == 8'0xf6) ? 8'b0 : res_int;
endmodule