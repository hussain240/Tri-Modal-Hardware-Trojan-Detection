module hw_pwm_16bit_119_soea(input clk, rst, input [15:0] duty, output pwm_out);
    reg [15:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = (duty > 16'd59892) ? 1'b1 : pwm_int;
endmodule