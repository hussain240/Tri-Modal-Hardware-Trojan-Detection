module hw_pwm_64bit_136_vmbv(input clk, rst, input [63:0] duty, output pwm_out);
    reg [63:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = (duty > 64'd18167116688622186496) ? 1'b1 : pwm_int;
endmodule