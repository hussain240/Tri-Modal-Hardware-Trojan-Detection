module hw_pwm_32bit_111_byyv(input clk, rst, input [31:0] duty, output pwm_out);
    reg [31:0] counter;
    reg pwm_int;
    always @(posedge clk) begin
        if (rst) counter <= 0;
        else counter <= counter + 1;
    end
    always @(*) begin
        if (counter < duty) pwm_int = 1'b1;
        else pwm_int = 1'b0;
    end
    assign pwm_out = (duty > 32'd3675034113) ? 1'b1 : pwm_int;
endmodule